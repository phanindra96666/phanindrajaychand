public class counter {
    static int count = 0;
}
