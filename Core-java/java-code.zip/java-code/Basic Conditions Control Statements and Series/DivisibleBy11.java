public class DivisibleBy11 {
    public static void main(String[] args) {
        for(int i=250;i<550;i++){
            if (i%11==0) {
                System.out.println(i);
            }
        }
    }
}
